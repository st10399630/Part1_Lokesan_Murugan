package com.example.calcapp20

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val num1EditText:EditText = findViewById(R.id.num1EditText)
        val num2EditText:EditText = findViewById(R.id.num2EditText)
        var resultTextView: TextView = findViewById(R.id.resultTextView)
        var addButton:Button = findViewById(R.id.addButton)
        var subtractButton:Button = findViewById(R.id.subtractButton)
        var multiplyButton:Button = findViewById(R.id.multiplyButton)
        var divisionButton:Button = findViewById(R.id.divisionButton)

        addButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val sum = num1 + num2
            resultTextView.text = "" + num1 + "+" + num2 + "=" + sum
        }
        subtractButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val sum = num1 - num2
            resultTextView.text = "" + num1 + "-" + num2 + "=" + sum
        }
        multiplyButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val sum = num1 * num2
            resultTextView.text="" + num1 + "*" + num2 + "=" + sum
        }
        divisionButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val sum = num1 / num2
            resultTextView.text="" + num1 + "/" + num2 + "=" + sum


        }
        }
        }


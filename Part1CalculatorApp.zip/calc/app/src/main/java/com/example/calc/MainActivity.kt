package com.example.calc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var addButton: Button
    private lateinit var subtractButton: Button
    private lateinit var multiplyButton: Button
    private lateinit var divideBTN: Button
    private lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

         num1EditText = findViewById(R.id.num1EditText)
         num2EditText = findViewById(R.id.num2EditText)
        addButton = findViewById(R.id.addButton)
        subtractButton = findViewById(R.id.subtractButton)
        multiplyButton = findViewById(R.id.multiplyButton)
        divideBTN = findViewById(R.id.divideBTN)
        resultTextView = findViewById(R.id.resultTextView)

        addButton.setOnClickListener {
            performOperation('+')
            val num1EditText = num1EditText.text.toString().toInt()
            val num2EditText = num2EditText.text.toString().toInt()
            val sum = num1EditText + num2EditText
            resultTextView.text = sum.toString()


        //when this button is clicked, this expression will be executed,in accordance to the character used

        }
        subtractButton.setOnClickListener {
            performOperation('-')
            val num1EditText = num1EditText.text.toString().toInt()
            val num2EditText = num2EditText.text.toString().toInt()
            val sum = num1EditText - num2EditText
            resultTextView.text = sum.toString()
        }
        multiplyButton.setOnClickListener {
            performOperation('*')
            val num1EditText = num1EditText.text.toString().toInt()
            val num2EditText = num2EditText.text.toString().toInt()
            val sum = num1EditText * num2EditText
            resultTextView.text = sum.toString()
        }
        divideBTN.setOnClickListener { '/' }
        val num1EditText = num1EditText.text.toString().toInt()
        val num2EditText = num2EditText.text.toString().toInt()
        val sum = num1EditText / num2EditText
        resultTextView.text = sum.toString()


    }

    private fun performOperation(operator: Char) {
        val num1 =
            num1EditText.text.toString().toDouble()
        val num2 =
            num2EditText.text.toString().toDouble()
        val result = when (operator) {
            '+' -> num1 + num2 //according to the character used, in this line num1 will add num 2
            '-' -> num1 - num2 //num 2 subtracts from num1
            '*' -> num1 * num2 //num1 and num2 is multiplied
            '/' -> num1 / num2 // divides num1 by num2

            else -> throw IllegalArgumentException("Sorry! that's an invalid operator!!")
            //https://youtu.be/v24Bhk7wqI8
            //https://youtu.be/Zi1XgFTUH9k
        }
    }
    }
